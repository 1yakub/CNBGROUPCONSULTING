<?php
/**
 * Template Name: Service - Registered Agent
 * Description: Template for the Registered Agent service page
 * 
 * @package CNB_Consulting_Theme
 */

get_header(); ?>

<main id="primary" >
    <?php get_template_part('template-parts/registered-agent/hero'); ?>
    
    <?php get_template_part('template-parts/registered-agent/explanation'); ?>
    
    <?php get_template_part('template-parts/registered-agent/features'); ?>
    
    <?php get_template_part('template-parts/registered-agent/pricing'); ?>
    
    <?php get_template_part('template-parts/registered-agent/benefits'); ?>
    
    <?php get_template_part('template-parts/registered-agent/cta'); ?>
</main>

<?php get_footer(); ?>