<?php
/**
 * Meta Boxes Registration
 * 
 * @package CNB_Consulting_Theme
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// No meta boxes needed - using hard-coded pages for services
// All service content is managed through static page templates