        <div class="text-center mb-16">
            <h2 class="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Lease Agreement Types</h2>
            <p class="text-xl text-gray-600 max-w-3xl mx-auto">Professional lease agreements for every property type and situation</p>
        </div>