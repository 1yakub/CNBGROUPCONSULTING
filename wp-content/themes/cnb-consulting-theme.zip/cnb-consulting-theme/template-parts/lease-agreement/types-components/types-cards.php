<?php
/**
 * Lease Agreement - Types Cards Components
 * 
 * @package CNB_Consulting_Theme
 */
?>

<?php include get_template_directory() . '/template-parts/lease-agreement/types-components/types-cards-components/types-primary.php'; ?>

<?php include get_template_directory() . '/template-parts/lease-agreement/types-components/types-cards-components/types-specialty.php'; ?>

<?php include get_template_directory() . '/template-parts/lease-agreement/types-components/types-cards-components/types-land.php'; ?>