<?php
/**
 * Lease Agreement - Importance Content Components
 * 
 * @package CNB_Consulting_Theme
 */
?>

<?php include get_template_directory() . '/template-parts/lease-agreement/importance-components/importance-content-components/comparison-cards.php'; ?>

<?php include get_template_directory() . '/template-parts/lease-agreement/importance-components/importance-content-components/info-cards.php'; ?>