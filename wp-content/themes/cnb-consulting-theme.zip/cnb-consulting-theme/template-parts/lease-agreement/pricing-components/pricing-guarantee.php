        <div class="text-center mt-12">
            <div class="inline-flex items-center space-x-3 bg-blue-50 border border-blue-200 rounded-lg p-6">
                <span class="text-3xl">⚖️</span>
                <div class="text-left">
                    <div class="font-bold text-gray-900">Legal Protection Worth Thousands</div>
                    <div class="text-gray-600">Professional lease prevents costly disputes and liability</div>
                </div>
            </div>
        </div>