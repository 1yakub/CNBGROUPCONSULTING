<!-- Lease Types Section -->
<section id="types" class="py-16 lg:py-24 bg-white">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
<?php include get_template_directory() . '/template-parts/lease-agreement/types-components/types-header.php'; ?>

<?php include get_template_directory() . '/template-parts/lease-agreement/types-components/types-cards.php'; ?>
    </div>
</section>