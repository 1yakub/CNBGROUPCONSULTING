<?php
/**
 * Registered Agent Features Header
 * 
 * @package CNB_Consulting_Theme
 */
?>

<div class="text-center mb-16">
    <h2 class="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Complete Registered Agent Service</h2>
    <p class="text-xl text-gray-600">Everything you need for compliance and peace of mind</p>
</div>