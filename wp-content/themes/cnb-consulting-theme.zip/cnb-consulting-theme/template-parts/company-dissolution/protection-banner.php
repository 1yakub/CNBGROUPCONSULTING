<!-- Legal Protection Banner -->
<div class="text-center mt-12">
    <div class="inline-flex items-center space-x-3 bg-blue-50 border border-blue-200 rounded-lg p-6">
        <span class="text-3xl">🛡️</span>
        <div class="text-left">
            <div class="font-bold text-gray-900">Complete Legal Protection</div>
            <div class="text-gray-600">Proper closure protects you from future claims and liabilities</div>
        </div>
    </div>
</div>