<div class="text-center mt-12">
    <div class="inline-flex items-center space-x-3 bg-green-50 border border-green-200 rounded-lg p-6">
        <span class="text-3xl">💰</span>
        <div class="text-left">
            <div class="font-bold text-gray-900">ROI: First Purchase Pays for Service</div>
            <div class="text-gray-600">$79 service fee typically saves $500+ on first order</div>
        </div>
    </div>
</div>