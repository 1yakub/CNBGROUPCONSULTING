        <div class="text-center mb-16">
            <h2 class="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Resale Certificate Benefits</h2>
            <p class="text-xl text-gray-600">Save money and improve cash flow with tax-exempt purchasing</p>
        </div>