<?php
/**
 * Tax-free allowance comparison section
 */
get_template_part('template-parts/resale-certificate/benefits-components/benefits-content-components/allowed-prohibited');
?>

<?php
/**
 * Benefits cards section
 */
get_template_part('template-parts/resale-certificate/benefits-components/benefits-content-components/benefits-cards');
?>