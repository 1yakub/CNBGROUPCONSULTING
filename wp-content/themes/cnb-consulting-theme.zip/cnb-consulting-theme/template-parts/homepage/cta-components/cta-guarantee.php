<div class="flex justify-center">
    <div class="bg-white bg-opacity-10 rounded-lg px-6 py-4 flex items-center">
        <span class="text-2xl mr-4">✅</span>
        <div class="text-left">
            <div class="font-bold text-white mb-1"><?php _e('Money-Back Guarantee', 'cnb-consulting-theme'); ?></div>
            <div class="text-blue-200 text-sm"><?php _e('100% satisfaction or full refund', 'cnb-consulting-theme'); ?></div>
        </div>
    </div>
</div>