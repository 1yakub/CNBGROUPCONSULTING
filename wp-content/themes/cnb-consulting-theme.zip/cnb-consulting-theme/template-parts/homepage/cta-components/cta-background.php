<!-- Background Pattern -->
<div class=" inset-0 opacity-10">
    <div class=" inset-0 !bg-[#020617] skew-y-1"></div>
</div>