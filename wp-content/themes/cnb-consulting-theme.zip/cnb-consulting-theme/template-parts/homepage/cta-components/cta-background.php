<!-- Background Pattern -->
<div class="absolute inset-0 opacity-10">
    <div class="absolute inset-0 bg-gradient-to-r from-transparent via-white to-transparent transform skew-y-1"></div>
</div>