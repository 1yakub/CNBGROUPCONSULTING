<?php $company_stats = cnb_get_company_info(); ?>
