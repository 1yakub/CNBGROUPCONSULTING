<!-- Services Categories Introduction -->
<section class="py-16 lg:py-24 bg-white">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="text-center mb-16">
            <h2 class="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Complete Business Solutions</h2>
            <p class="text-xl text-gray-600 max-w-3xl mx-auto">Everything you need to start, run, and protect your business - all in one place</p>
        </div>