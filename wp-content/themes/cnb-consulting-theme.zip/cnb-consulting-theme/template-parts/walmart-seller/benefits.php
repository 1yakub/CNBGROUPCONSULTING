<!-- Why Walmart Marketplace -->
<section id="benefits" class="py-16 lg:py-24 bg-white">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <?php include get_template_directory() . '/template-parts/walmart-seller/benefits-components/benefits-header.php'; ?>
        <?php include get_template_directory() . '/template-parts/walmart-seller/benefits-components/benefits-cards.php'; ?>
        <?php include get_template_directory() . '/template-parts/walmart-seller/benefits-components/benefits-footer.php'; ?>
    </div>
</section>