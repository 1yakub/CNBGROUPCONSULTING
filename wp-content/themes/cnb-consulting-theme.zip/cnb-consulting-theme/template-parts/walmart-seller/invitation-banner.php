<div class="text-center">
    <div class="inline-flex items-center space-x-3 bg-blue-50 border border-blue-200 rounded-lg p-6">
        <span class="text-3xl">🎯</span>
        <div class="text-left">
            <div class="font-bold text-gray-900">Invitation-Only Platform</div>
            <div class="text-gray-600">We help you get approved with proven application strategies</div>
        </div>
    </div>
</div>