        <div class="bg-blue-50 border-l-4 border-cnb-primary p-6 rounded-lg">
            <div class="flex items-start space-x-3">
                <div class="text-2xl">📊</div>
                <div>
                    <h4 class="font-bold text-gray-900 mb-2">Success Statistics</h4>
                    <p class="text-gray-700">
                        Walmart sellers typically see 20-30% higher profit margins compared to Amazon due to lower fees and less competition. The platform is growing 40%+ year-over-year.
                    </p>
                </div>
            </div>
        </div>