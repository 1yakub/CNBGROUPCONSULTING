<!-- Hero Section -->
<section class="relative bg-gradient-to-br from-cnb-primary to-blue-900 text-white py-16 lg:py-24">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="text-center max-w-4xl mx-auto">
            <?php include get_template_directory() . '/template-parts/walmart-seller/hero-components/hero-content.php'; ?>
        </div>
    </div>
</section>